<?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") { 
 
        
        $enq_name=$_POST["name"];
        $enq_email = $_POST["email"];
         $mobile = $_POST["country"].$_POST["mobile"];
        $project = $_POST["project"];  
        $remark = "Project: {$_POST['project']}, Location: {$_POST['locations']}, Visitor IP: {$_POST['visitor_ip']}, Lead Location: {$_POST['leadLocation']}";
 
        $sourceid=1386;
        $api_key="36db0bb612c6408b80637d940351b53c060521043458";
             
                   
            if(is_array($_POST)){ foreach ($_POST as $key => $value) { ${$key} = $value; }}
                
             ## B2BBricks CRM code
        
        $postdata=array("name"=>$name, "mobile"=>$mobile, "email"=>$email, "remark"=>$remark, "project"=>$project);  
        $urldata=array("api_key"=>$api_key,"source"=>$sourceid, "responsetype"=>$type,"account"=>$account);
        $result=httpPost($urldata,$postdata); 
        redirect("../thankyou.html");
        
        
        ## End code##
            
    }else{
        $_POST['status'] = 'fail';
        $alert = "Some internal error occurred. Please try again later.";
        echo "<script type='text/javascript'>alert('$alert');</script>";
    }
        
function httpPost($urldata, $data)
{
    $baseurl="https://connector.b2bbricks.com/api/Integration/postResponse"; 
    $url = $baseurl."?".http_build_query($urldata); 
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}
function redirect($url) {
    header('Location: '.$url);
    die();
}    
?>